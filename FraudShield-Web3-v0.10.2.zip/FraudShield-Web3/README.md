# FraudShield Web3 (v0.10.2)

FraudShield Web3 is a Chrome extension that helps someone who has been defrauded organise their evidence and draft a structured report for their bank and the Gardaí. The AI runs on your own computer through Ollama. Nothing is sent to a cloud AI service, and nothing is submitted to anyone for you.

This is a student prototype from the MSc in Fintech at National College of Ireland. Use fictional data when you try it.

## Quick start

1. Install Ollama from https://ollama.com/download.
2. Download the models: `ollama pull llama3.2:3b` and, for screenshots and scanned PDFs, `ollama pull llava:7b`.
3. Let the extension talk to Ollama: set the environment variable `OLLAMA_ORIGINS=chrome-extension://*`, then restart Ollama (details in section B below).
4. Unzip this folder, open `chrome://extensions`, turn on **Developer mode**, click **Load unpacked** and choose the folder that contains `manifest.json`.
5. Pin FraudShield from the puzzle-piece menu and click its icon to start a case.

## Version 0.10.2: SHA-256 fingerprints in the report PDF

- Report Studio now starts the evidence section with an "Evidence integrity (SHA-256)" table: evidence ID, file name, full SHA-256 fingerprint and status (verified, changed since fingerprinted, not fingerprinted yet, or typed note). It prints with the PDF.
- Report Studio updates the evidence and fingerprints by itself when the case changes in the popup, so fingerprinting after opening the report no longer leaves the PDF without hashes. Your edits to the draft are not touched.
- "Save as PDF" now tells you to choose "Save as PDF" as the destination in Chrome's print window.
- To include fingerprints: in the popup, step 5, click Fingerprint files, then open Report Studio and click Save as PDF. The separate integrity manifest (JSON) is still available from Download manifest.

## Version 0.10.1: interface refresh

This version changes how the extension looks. The evidence handling, AI prompts, hashing, storage keys and export format are the same as version 0.10.0.

- The popup is reorganised into five numbered steps (Case, Evidence, AI review, Report, Export), with a progress rail at the top that fills in as you go. The rail is drawn by `ui.js`, which only reads local storage and never writes to it.
- Files can be dragged onto the "Add files" area.
- Model settings are tucked into a "Model settings" section under the AI review step.
- The AI review page and Report Studio share the new look, and the Report Studio sidebar links now jump to the case file, the draft and the evidence attachments.
- New toolbar and extension icons.
- Fixed a stray "\n" that showed as text in the popup, and an empty `@import` in `report.css`.
- Known issue carried over from 0.10.0: "Delete local case data" removes the case record but not the stored AI reviews or report draft.

---

# Development history

## Features
- Multi-evidence case manager: screenshots, user-selected files, notes.
- Category-specific checklist.
- Local AI review using Ollama's HTTP API.
- AI review runs through local Ollama. Stage 7.1 extracts plain-text evidence and user-triggered webpage text; optional local vision model can inspect images.
- User reviews and consents before export.
- No cloud AI service or API key in this implementation.

## A. Install Ollama
1. Download Ollama from https://ollama.com/download and install it.
2. Open a terminal / PowerShell and run:
   `ollama pull llama3.2:3b`
3. Test:
   `ollama run llama3.2:3b`
   Ask it a simple question, then exit the chat. Keep Ollama running in the background.

You can use another model; set the model name in FraudShield's AI section. The model must be downloaded first (`ollama pull MODEL_NAME`).

## B. Configure Ollama to accept requests from the Chrome extension
Ollama listens locally at `http://localhost:11434`. Chrome extensions may be blocked by Ollama's origin/CORS policy. If the extension shows a connection/CORS error:

**Windows PowerShell (temporary for this terminal session):**
1. Quit Ollama from its tray icon.
2. Open PowerShell and run:
   `$env:OLLAMA_ORIGINS="chrome-extension://*"`
3. Start Ollama from that same PowerShell session (e.g. run `ollama serve`; if Ollama is already managed by the desktop app, launch the app from the configured environment instead).
4. Retry the extension.

Depending on your Ollama version/platform, setting environment variables for the Ollama desktop app may require configuring the variable in Windows user environment variables and restarting Ollama. See official Ollama docs for environment configuration.

Security note: only add origins you trust. Do not expose Ollama's port to the public internet; keep it bound to localhost.

## C. Install / update extension
1. Extract this ZIP.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Reload the existing FraudShield extension, or click Load unpacked and select the extracted folder containing `manifest.json`.

## D. Try AI review
1. Create a demo case (use fictional data).
2. Select fraud type and enter a short description.
3. Add a few evidence items/notes.
4. Scroll to **AI Evidence Completeness Assistant**.
5. Confirm model name `llama3.2:3b`.
6. Click **Review case with local AI**.

## Troubleshooting
- `model not found`: run `ollama pull llama3.2:3b`.
- connection refused: start Ollama / `ollama serve`.
- fetch/CORS/network error: check `OLLAMA_ORIGINS`, restart Ollama, and make sure the extension host permission is present.
- slow response: try a smaller model, such as `llama3.2:1b` (if available for your machine).
- If browser extension origin still fails: run Ollama API test from terminal first, then use the extension's error message. Do not set CORS to unrestricted `*` unless only in a controlled local test environment.

## Limitations / ethics
- This is a project prototype, not an official fraud reporting service.
- The model may hallucinate, miss information, or give inappropriate suggestions. Verify all output.
- It does not decide whether fraud occurred or whether evidence is legally sufficient.
- Stage 7.1 reads .txt/.eml/.csv/.json evidence in-browser and captures page title, URL, meta description, and visible text only after user clicks Capture. Optional image analysis uses Ollama on localhost. PDF text extraction is not implemented in this build.
- Do not enter passwords, PINs, OTPs, full card details, or unnecessary personal data.
- Do not store sensitive personal evidence on blockchain. Stage 3 does not yet use Web3.


## Stage 3.1 — AI report UI polish
- AI output opens in a dedicated full-size extension tab.
- Markdown-style headings, lists, and emphasis are formatted for readability.
- Popup shows status and an “Open formatted AI report” button.
- Report is stored locally in extension storage. No remote hosting.


## Stage 3.2 autosave fix
Case name, description, and fraud category autosave to chrome.storage.local as you type/change them. You no longer need to click Save case details before switching tabs or starting AI review. Chrome extension popups close when focus moves away, but the saved draft should remain when you reopen the popup.


## Stage 4 — AI report generation
1. Update/reload the extension from this folder.
2. Make sure Ollama is running and the selected model is available.
3. Fill case details and add evidence/notes.
4. Click **Generate fraud report** in the popup.
5. The report opens in a full tab. Edit the text, click **Save edits**, then **Print / Save as PDF**.
6. In Chrome's print dialog, select **Save as PDF**.

The AI report is generated from the case description and evidence inventory metadata/notes. It does not read attachments or invent attachment contents. Verify facts and redact information before sharing. This remains a draft and is not submitted to any authority.


## Stage 4.1 — Branded Report Studio UI
The report page now has FraudShield branding, a full-page workspace layout, a formatted editable document (Markdown is rendered as headings/lists/bold text), save/reload, TXT export, and browser print-to-PDF. Editing is WYSIWYG via contenteditable. Press Save changes before closing the tab. The print stylesheet removes workspace controls and prints the report document.


## Stage 4.2 — Print/PDF fix
Adds A4 print rules to remove editor clipping/scrollbars and forces the report content to expand fully when printing. If you still see the old plain textarea report page, ensure Chrome is loading this version's folder: the extension URL/ID should match the extension you reloaded. Use Reload in chrome://extensions, then generate a fresh report.


## Stage 4.3 — Empty draft protection
Report Studio detects missing/blank report content, displays clear recovery instructions, and blocks save/print/TXT export when content is empty. This prevents an empty editor from overwriting a generated report. If the stored report has already been erased, regenerate it from the extension popup; case details should still be saved.


## Stage 4.4 — Report page null-reference fix
Fixed the report.js error caused by attempting to set textContent on a missing element with id `title`. The page title is now updated via `document.title`. Reload the unpacked extension and regenerate/open Report Studio.


## Stage 4.5 — Attach evidence images and expanded report
The Report Studio now reads case evidence from `fraudshieldCaseV3` and adds an Evidence Attachments section after the editable report. Browser screenshots and uploaded image evidence (data:image/*) are displayed inline and included in Chrome print-to-PDF. Non-image files are listed with metadata and should be shared separately through case JSON export. The Ollama report prompt was expanded with a detailed incident report structure and explicit safeguards against inventing details.

**Note:** Report evidence is fetched from the currently saved case in local extension storage. Ensure the case is open/current when opening the report. If screenshots are very large, Chrome print may paginate them; images are constrained to fit the printed page.


## Stage 5 — Local SHA-256 evidence integrity

### Added
- `Hash & verify evidence (SHA-256)` computes a SHA-256 fingerprint locally in Chrome for image and file evidence stored as data URLs.
- Hashes are persisted with the case evidence.
- If a previously hashed file changes, the extension reports `MISMATCH` and preserves the original hash rather than replacing it.
- `Download integrity manifest` exports a JSON manifest with case metadata, evidence IDs, file metadata, SHA-256 hashes, timestamps, and integrity status.
- Report Studio evidence attachment cards display available hashes and integrity statuses.
- No evidence bytes are sent to Ollama, a server, or a blockchain by this feature.

### Important limitation
SHA-256 only detects whether the bytes match a previously recorded fingerprint. It does not prove that the screenshot is genuine, that the contents are true, or that it was captured at the stated time. A user who edits an evidence file before its first hash can hash the edited version. Keep the original evidence and manifest together.

### Use
1. Open the case in the popup.
2. Click **Hash & verify evidence (SHA-256)**.
3. Download the **Integrity manifest** and retain it with the original evidence.
4. For a later integrity check, reopen the same case and click Hash & verify. A mismatch is displayed if a previously hashed item has changed.

This stage is local-only. Blockchain anchoring (e.g., Sepolia + MetaMask) is a separate Stage 6 step and should only store hashes/non-sensitive identifiers, never screenshots or personal details.


## Stage 7 — Evidence checklist persistence + local audit trail

- Category-specific checklist selections are saved locally and restored when reopening the popup.
- Checklist items are suggestions, not official/legal requirements; missing evidence does not block reporting.
- Local audit log records case opening, case detail edits, evidence capture/upload/removal, timeline notes, AI review, report generation, hash operations, and export actions.
- Download the activity history as JSON using **Download audit trail (JSON)**.
- Audit trail is local and can be modified/deleted by the device user. Device timestamps are not independently trusted; it is a workflow log, not a legally certified audit trail.


## Stage 7.1 — Evidence-aware AI reconciliation

### What's changed
- The former AI prompt explicitly prevented file-content analysis. That limitation is removed.
- When the user explicitly captures a webpage, FraudShield uses `activeTab` + `scripting` to collect page title, URL, meta description and visible body text (up to 18,000 characters), along with a screenshot. This is user-triggered and limited to the active page.
- `.txt`, `.eml`, `.csv`, `.json`, and Markdown/log text files are read locally from the uploaded data URL and passed to local Ollama, with text length limits.
- Images/screenshots may be analyzed by a local Ollama vision model. Set the optional vision model field to a model you have installed (example: `llava:7b`; first install with `ollama pull llava:7b`). If the vision model is not installed, image contents will not be visually read; only page text/metadata may be available.
- The AI review requests structured JSON with source-attributed facts, category mismatch suggestions, amount/date/transaction conflicts, missing-evidence suggestions and follow-up questions.
- The AI may suggest a different category, but it does not silently change the user's selected category. User must click **Apply suggested category** or keep the existing category.
- Report generation now includes extracted evidence text and AI reconciliation output. Conflicting values should be disclosed, not silently reconciled.
- Evidence text and images are sent only to the local Ollama API (`localhost:11434`), not a cloud AI endpoint. Keep Ollama bound to localhost.

### Try it
1. Reload the extension at `chrome://extensions`.
2. For webpage evidence, open the target website and click **Capture current webpage** in FraudShield. This captures visible screenshot and page title/URL/visible text after explicit user action.
3. Add .txt/.eml/.csv evidence files. PDF files are retained in inventory, but this version does not extract PDF text.
4. For screenshot OCR/image understanding, install a local vision model:
   `ollama pull llava:7b`
   Then set **Optional vision model** to `llava:7b`. It may require significant memory and processing time.
5. Run **Review case with local AI**. Review evidence citations and category/amount/date discrepancy warnings.
6. If AI recommends a different category, choose whether to apply it. The category remains unchanged unless you explicitly accept the suggestion.
7. Generate the report again after accepting/rejecting discrepancies, then edit and verify it.

### Important limitations
- Webpage extraction is user-triggered and limited to the currently active tab; it is not background browsing or whole-site crawling.
- DOM visible text may omit hidden/dynamically loaded content. Screenshot and visible text may not show the entire page.
- OCR / vision output can misread small text, logos, amounts, dates or identifiers. Always compare against the original.
- PDF extraction is not implemented. For PDFs, use a text export or paste relevant content as a case note; do not rely on filename-only AI suggestions.
- AI does not automatically determine fraud type or change category. Human confirmation required.
- AI findings are not legal advice or official reporting guidance.
- Uploaded evidence can contain malicious prompt-injection text; the AI is instructed to treat evidence as data, not instructions, but that safeguard is not guaranteed.

## Stage 7.2 — Evidence-grounded reconciliation fixes

This build fixes the local AI review regressions reported during testing:
- Includes captured webpage text alongside page URL/title metadata (not just a boolean flag).
- Adds local deterministic extraction of common visible fact patterns: money amounts, dates, URLs, email addresses, and references. These are clues, not verified facts.
- Keeps evidence content within bounded per-item excerpts to reduce oversized Ollama prompts.
- Adds bounded Ollama generation options (`num_ctx`, `num_predict`, `repeat_penalty`) for AI review and report generation.
- Adds rule-based category cue scoring, including stronger cues for employment/job-fee scams versus romance scams. AI can still review the cues; category changes remain user-confirmed.
- Explicitly instructs the model not to label an employment-fee scam as romance unless actual romance context is present.

Limitations: this remains a local educational prototype. PDF text extraction is still not implemented in this package; PDF attachments should be converted to text or key facts entered as notes. Images require a compatible Ollama vision model. AI findings can be wrong and must be reviewed. The keyword/rule classification is heuristic and can produce false positives.


## Stage 7.3 — Evidence-grounded reasoning upgrade
- Reworked the local AI system prompt into a source-by-source analysis workflow: evidence inventory, fact extraction, timeline, cross-source comparison, category-vs-narrative comparison, completeness review, and uncertainty handling.
- Added output sections for evidence coverage, source-specific fact type/confidence/quotes, timeline, and discrepancy severity.
- Instructs the AI to distinguish user claims, direct document evidence, webpage content, inference, and unknowns.
- Explicitly prohibits unsupported claims such as "the recruiter gained trust" unless source evidence states that.
- Instructs the AI to avoid duplicate missing-evidence requests and disclose unreadable/partially inspected documents.
- Category UI now prioritizes the model's evidence-based category recommendation; the rule-based keyword score is only a fallback. The rule heuristic no longer silently wins over the AI's analysis.
- Increased generation output budget to 1,400 tokens and context to 6,144 with lower temperature. This may increase latency/memory use.

**Model quality:** Prompt improvements do not make a 3B model equivalent to ChatGPT. For harder multi-document reconciliation, try a stronger local model if your computer supports it (for example a 7B/8B instruction model). Keep the local-only privacy approach and evaluate with fictional evidence packs.

**PDF caveat:** This package still does not extract PDF text. PDF files can appear in the evidence inventory but their contents are not available to the text model unless separately extracted or entered as notes. Do not interpret a filename as evidence content. OCR/vision support applies to images/screenshots only, and may misread text.

## Stage 7.4 — local PDF text extraction dependency

This build includes the PDF extraction integration, but the PDF.js runtime files are not bundled in this archive. Add these two files to the **same folder as `manifest.json` and `popup.js`** before testing PDF extraction:

- `pdf.min.mjs` (PDF.js 4.10.38 API): https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs
- `pdf.worker.min.mjs` (matching PDF.js 4.10.38 worker): https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs

Open each link in Chrome, save the file (Ctrl+S), and ensure the exact filename is retained. Use the matching API and worker version; mixing versions can cause worker/API mismatch errors. PDF.js is Mozilla's Apache-2.0-licensed PDF parser.

Then reload FraudShield at `chrome://extensions`.

### PDF extraction behaviour
- Runs in the extension locally; the PDF is not uploaded to a third-party server.
- Extracts selectable text from up to the first 20 pages and up to 18,000 characters per PDF in one review.
- Page labels are included in the extracted text for citation/context.
- Scanned/image-only PDFs may return no text. They require OCR (planned) or a local vision workflow; do not assume the PDF was read if extraction is empty.
- Password-protected PDFs may fail extraction. Do not enter or store sensitive document passwords in the case notes.
- AI can still misread extracted content. Check its evidence ID/page references against the original PDF.


## Stage 8 — Evidence Intelligence Engine (PDF text + scanned-page vision OCR)

This build improves evidence extraction and reconciliation locally:
- Bundles PDF.js API + matching worker files (`pdf.min.mjs`, `pdf.worker.min.mjs`) in the extension folder. No CDN dependency at runtime.
- Extracts selectable PDF text from up to 50 pages (up to 40,000 characters per PDF). Page labels are preserved.
- Detects pages with no selectable text. If a local Ollama vision model is configured, renders up to 3 such pages and sends the page images to Ollama at `localhost:11434` for local OCR/reading.
- For images and scanned PDF pages, configure a compatible vision model (e.g. `llava:7b`) and install it first with `ollama pull llava:7b`.
- Removes the previous hard-coded 2,500-character AI evidence excerpt. Uses a bounded evidence bundle (up to approximately 16,000 evidence characters across files) to reduce accidental omission while keeping the prompt within a practical local model context. Evidence is still clipped if the bundle is too large; clipping is flagged.
- Raises the review context/output budget to 8,192/1,800 tokens. This can increase RAM use and latency; use a lower setting if your computer struggles.
- Processing warnings are shown in the popup and included in the saved AI report.

### Reload / test Stage 8
1. Extract this ZIP into a new folder (do not overwrite your old working folder yet).
2. Open `chrome://extensions` and click **Reload** on FraudShield, or **Load unpacked** and choose the new folder.
3. Confirm PDF.js files are present beside `manifest.json` and `popup.js`.
4. Use a fictional case with PDFs, screenshots, and text evidence.
5. Set the vision model to a model you have already installed, such as `llava:7b`, if you want screenshot/scanned-page OCR.
6. Run AI review and inspect the evidence coverage and citations. Compare amounts, dates, names and quotes against the original files.

### Known limitations
- Vision OCR is best-effort, and currently reads at most 3 PDF pages that have no selectable text per PDF. It may miss text in a scanned page if the PDF contains some other selectable text.
- PDFs with more than 50 pages, text beyond 40,000 characters, or evidence bundles beyond the prompt budget may be partially processed; FraudShield should disclose partial extraction.
- The AI can still miss or hallucinate details, especially with small text, blurry images, multiple documents, or the small `llama3.2:3b` model. Always review original evidence.
- Local processing means the PDF/image content is sent to your local Ollama API, not a cloud AI provider, assuming Ollama is running on your own device and not exposed remotely.
- No evidence is submitted to Gardaí, a bank, Central Bank, or other authority automatically.


## Stage 9 — Background-friendly AI tasks and private audit export
- AI evidence review and report generation launch in a dedicated full extension tab, not the popup. Switching browser tabs no longer closes the execution page. Keep that task tab open until it finishes; closing it cancels the active request.
- Audit events remain in local `chrome.storage.local` and are not rendered as a visible event list. Click **Generate / download audit report (JSON)** to export them.
- This prototype does not have a cloud backend. Audit records are stored on the user's browser/device; they are not uploaded to a remote server.
- Long Ollama calls can still take time depending on model/context/CPU/GPU. This change prevents popup-close cancellation, not model latency.


## Stage 10A — Review state synchronization and report isolation

This update focuses on preventing stale AI review output from being displayed or reused:
- Each AI review receives a unique review ID.
- Reviews are stored under individual keys (`fraudshieldAIReview_<reviewId>`) in addition to the latest-review pointer.
- The review report tab opens with the exact review ID and loads that review only. It will not silently substitute another review if the requested review record is missing.
- Each review stores a SHA-256 fingerprint of the case/evidence snapshot, evidence IDs/count, and generation timestamp.
- Report generation reuses AI reconciliation only when the case ID and fingerprint match the current case/evidence snapshot. Otherwise it explicitly excludes the stale review.

### Stage 10A test checklist
1. Add evidence E01 and run review A. Confirm its review ID and evidence count.
2. Add E02 or change the case narrative/category and run review B. Confirm B has a different review ID and includes the latest evidence.
3. Open review A and review B separately; confirm each displays its own output.
4. Generate a report after changing the case/evidence. Confirm older AI reconciliation is not reused unless its fingerprint matches.
5. Reload the extension and verify the saved case and review records remain available.

### Notes
- This is a synchronization/isolation improvement, not a guarantee that the model reads every detail correctly. OCR, context limits, model hallucinations, and evidence interpretation still require validation.
- Review history is stored locally in Chrome extension storage. This update does not add a cloud backend.
