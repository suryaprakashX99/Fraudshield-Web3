const KEY="fraudshieldReportDraft", $=id=>document.getElementById(id);
let report=null;
function esc(s){return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}
function inline(s){return esc(s).replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\*(.+?)\*/g,"<em>$1</em>").replace(/`(.+?)`/g,"<code>$1</code>");}
function markdownToHtml(md){
 const lines=(md||"").replace(/\r/g,"").split("\n");let out=[],para=[],list=null;
 const flushPara=()=>{if(para.length){out.push("<p>"+para.map(inline).join("<br>")+"</p>");para=[];}};
 const flushList=()=>{if(list){out.push(`</${list}>`);list=null;}};
 for(let line of lines){const t=line.trim();if(!t){flushPara();flushList();continue;}
 let m=t.match(/^(#{1,3})\s+(.+)$/);if(m){flushPara();flushList();let level=m[1].length;out.push(`<h${level}>${inline(m[2])}</h${level}>`);continue;}
 m=t.match(/^[-*]\s+(.+)$/);if(m){flushPara();if(list!=="ul"){flushList();list="ul";out.push("<ul>");}out.push(`<li>${inline(m[1])}</li>`);continue;}
 m=t.match(/^\d+[.)]\s+(.+)$/);if(m){flushPara();if(list!=="ol"){flushList();list="ol";out.push("<ol>");}out.push(`<li>${inline(m[1])}</li>`);continue;}
 if(/^>\s?/.test(t)){flushPara();flushList();out.push(`<blockquote>${inline(t.replace(/^>\s?/,""))}</blockquote>`);continue;}
 if(t==="---"||t==="___"){flushPara();flushList();out.push("<hr>");continue;}
 flushList();para.push(t);
 }
 flushPara();flushList();
 return out.join("\n");
}

const CASE_KEY="fraudshieldCaseV3";
function safeText(v){return String(v??"").replace(/[<>]/g,"");}
// Integrity summary: one table of SHA-256 fingerprints at the start of the evidence section.
function integrityBlock(items){
 const box=document.createElement("section");box.className="integrity";
 const h=document.createElement("h3");h.textContent="Evidence integrity (SHA-256)";box.append(h);
 const hashed=items.filter(it=>it.sha256);
 const note=document.createElement("p");note.className="integrity-note";
 if(!hashed.length){
  box.classList.add("empty");
  note.textContent="No files have been fingerprinted yet. In the FraudShield popup, go to step 5 and click Fingerprint files. This page updates by itself, then save the PDF.";
  box.append(note);return box;
 }
 note.textContent=`${hashed.length} of ${items.length} evidence items have a SHA-256 fingerprint. A matching fingerprint shows the file hasn’t changed since it was fingerprinted. It doesn’t prove the file is genuine or when it was made.`;
 box.append(note);
 const table=document.createElement("table");table.className="integrity-table";
 const head=document.createElement("thead");head.innerHTML="<tr><th>ID</th><th>File</th><th>SHA-256 fingerprint</th><th>Status</th></tr>";table.append(head);
 const body=document.createElement("tbody");
 items.forEach((it,i)=>{
  const tr=document.createElement("tr");
  const status=it.sha256?(it.integrityStatus==="MISMATCH"?"Changed since fingerprinted":"Verified"+(it.lastVerifiedAt?" "+new Date(it.lastVerifiedAt).toLocaleString():"")):(it.dataUrl?"Not fingerprinted yet":"Typed note, nothing to fingerprint");
  [`E${String(i+1).padStart(2,"0")}`,it.name||`Evidence ${i+1}`,it.sha256||"—",status].forEach((v,j)=>{const td=document.createElement("td");td.textContent=v;if(j===2)td.className="hash";if(j===3&&it.integrityStatus==="MISMATCH")td.className="mismatch";tr.append(td);});
  body.append(tr);
 });
 table.append(body);box.append(table);return box;
}
function renderEvidence(caseData){
 const host=$("evidenceAttachments");if(!host)return;
 const items=caseData?.items||[];
 host.innerHTML="<h2>Evidence attachments & screenshots</h2>";
 if(!items.length){host.innerHTML+='<p class="evidence-empty">No files or screenshots are attached to this case. Add evidence from the FraudShield popup, then regenerate/open the report.</p>';return;}
 host.append(integrityBlock(items));
 items.forEach((item,index)=>{
  const card=document.createElement("article");card.className="evidence-card";
  const badge=document.createElement("span");badge.className="ev-badge";badge.textContent=`Evidence E${String(index+1).padStart(2,"0")} · ${item.kind||"Attachment"}`;
  const title=document.createElement("h3");title.textContent=item.name||`Evidence ${index+1}`;
  const meta=document.createElement("div");meta.className="ev-meta";
  const parts=[];if(item.addedAt)parts.push("Added: "+new Date(item.addedAt).toLocaleString());if(item.capturedAt)parts.push("Captured: "+new Date(item.capturedAt).toLocaleString());if(item.url)parts.push("Source URL: "+item.url);if(item.title)parts.push("Page title: "+item.title);if(item.size)parts.push("Size: "+(item.size/1024).toFixed(1)+" KB");if(item.source)parts.push("Source: "+item.source);if(item.sha256)parts.push("SHA-256: "+item.sha256);if(item.integrityStatus)parts.push("Integrity: "+item.integrityStatus);
  meta.textContent=parts.join(" · ");
  card.append(badge,title,meta);
  if(item.dataUrl && /^data:image\//i.test(item.dataUrl)){
   const img=document.createElement("img");img.src=item.dataUrl;img.alt=`Evidence image ${index+1}: ${item.name||"uploaded image"}`;img.loading="eager";card.append(img);
  }else if(item.note){
   const note=document.createElement("div");note.className="ev-note";note.textContent=item.note;card.append(note);
  }else{
   const note=document.createElement("p");note.className="ev-note";note.textContent=item.dataUrl?"File attachment stored in FraudShield. The file itself is not embedded in this PDF; use the exported case package to share it.":"Attachment record only; original file is not embedded.";card.append(note);
  }
  host.append(card);
 });
}

let draftMissing=false;
function load(){chrome.storage.local.get([KEY,CASE_KEY],r=>{
 renderEvidence(r[CASE_KEY]);
 report=r[KEY];
 if(!report){draftMissing=true;$("metadata").textContent="No saved report draft found. Generate a new report from FraudShield."; $("reportEditor").innerHTML='<div class="empty-state"><h2>Report draft not found</h2><p>Return to the FraudShield extension popup and click <strong>Generate fraud report</strong> again. Your case details and evidence inventory should remain saved.</p></div>'; $("saveState").textContent="No report draft";return;}
 $("caseTitle").textContent=report.caseName||"Untitled case";document.title=(report.caseName||"Incident Report")+" | FraudShield Report Studio";
 $("metadata").textContent=`${report.category||"Uncategorized"} · Generated ${report.generatedAt?new Date(report.generatedAt).toLocaleString():"time unavailable"} · ${report.model||"Local AI"}`;
 $("caseRef").textContent=report.caseId||"Not assigned";$("footerDate").textContent=`Draft generated ${report.generatedAt?new Date(report.generatedAt).toLocaleDateString():""} · not submitted`;
 const body=(report.draftHtml||"").trim() || markdownToHtml((report.draft||"").trim());
 if(!body.trim()){draftMissing=true;$("reportEditor").innerHTML='<div class="empty-state"><h2>AI report text is missing</h2><p>The saved report record exists, but its text is empty. <strong>Do not save this blank page.</strong> Go back to the FraudShield popup and generate the report again. This will create a fresh draft from your saved case.</p></div>';$("saveState").textContent="Missing report content — regenerate from popup";}
 else {draftMissing=false;$("reportEditor").innerHTML=body;$("saveState").textContent="Draft loaded · changes not yet saved";}
 });}
async function save(){
 if(!report||draftMissing){$("saveState").textContent="Cannot save: report text is missing. Generate a new report from the FraudShield popup.";return;}
 const text=$("reportEditor").innerText.trim();
 if(!text){$("saveState").textContent="Save blocked: report is empty. Your previous draft was not overwritten.";return;}
 report.draftHtml=$("reportEditor").innerHTML;report.draft=text;report.editedAt=new Date().toISOString();
 await chrome.storage.local.set({[KEY]:report});
 $("saveState").textContent="✓ Saved locally at "+new Date(report.editedAt).toLocaleTimeString();
 $("metadata").textContent=`${report.category||"Uncategorized"} · Last saved ${new Date(report.editedAt).toLocaleString()} · ${report.model||"Local AI"}`;
}
$("saveBtn").onclick=save;$("saveBottomBtn").onclick=save;
async function printReport(){if(draftMissing||!$("reportEditor").innerText.trim()){ $("saveState").textContent="Cannot print empty report. Generate a new draft first.";return;} await save();$("saveState").textContent="In the print window, set Destination to “Save as PDF”, then click Save.";document.body.classList.add("printing");setTimeout(()=>window.print(),150);}
$("printBtn").onclick=printReport;$("printBottomBtn").onclick=printReport;
window.addEventListener("afterprint",()=>document.body.classList.remove("printing"));
$("reloadBtn").onclick=()=>{if(confirm("Reload the last saved version? Unsaved edits will be discarded."))load();};
$("exportTxtBtn").onclick=async()=>{if(draftMissing||!$("reportEditor").innerText.trim()){ $("saveState").textContent="Cannot export empty report. Generate a new draft first.";return;} await save();const blob=new Blob([$("reportEditor").innerText],{type:"text/plain;charset=utf-8"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`FraudShield-${(report?.caseId||"case")}-report.txt`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000);};
$("reportEditor").addEventListener("input",()=>{$("saveState").textContent="Unsaved changes";});
// Keep evidence and fingerprints current when the case changes in the popup (the draft text is not touched).
chrome.storage.onChanged.addListener((changes,area)=>{if(area==="local"&&changes[CASE_KEY])renderEvidence(changes[CASE_KEY].newValue);});
load();