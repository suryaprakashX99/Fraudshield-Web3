// FraudShield Web3 — Stage 3. Capture only on an explicit user click.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "CAPTURE_VISIBLE_TAB") return;
  (async () => {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tab = tabs[0];
      if (!tab?.id || !tab.url) throw new Error("No active tab found.");
      if (/^(chrome|edge|about|chrome-extension):\/\//i.test(tab.url)) {
        throw new Error("This browser page cannot be captured. Open a regular website and try again.");
      }
      // activeTab + scripting permission: only run after the user clicks Capture in the extension.
      let pageContent={title:tab.title||"(untitled page)",url:tab.url,visibleText:"",metaDescription:""};
      try{
        const [result]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>{
          const meta=document.querySelector('meta[name="description"]')?.content||"";
          return {title:document.title||"",url:location.href,visibleText:(document.body?.innerText||"").slice(0,18000),metaDescription:meta};
        }});
        if(result?.result)pageContent={...pageContent,...result.result};
      }catch(e){pageContent.captureTextError="Page text could not be accessed; screenshot and URL/title were captured.";}
      const screenshot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
      sendResponse({ ok: true, evidence: {
        id: crypto.randomUUID(), kind: "Browser screenshot",
        name: (tab.title || "Captured webpage") + ".png",
        title: pageContent.title || tab.title || "(untitled page)", url: pageContent.url || tab.url,
        pageText: pageContent.visibleText||"", metaDescription:pageContent.metaDescription||"",
        capturedAt: new Date().toISOString(), dataUrl: screenshot,
        source: "User-triggered browser capture",
        captureTextError:pageContent.captureTextError||""
      }});
    } catch (err) { sendResponse({ ok: false, error: err?.message || "Capture failed." }); }
  })();
  return true;
});