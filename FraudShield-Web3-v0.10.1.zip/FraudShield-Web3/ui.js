// FraudShield Web3: progress rail and evidence count for the popup.
// Display only. Reads the same local storage keys as popup.js and never writes to them.
(() => {
  const CASE_KEY = "fraudshieldCaseV3";
  const KEYS = [CASE_KEY, "fraudshieldLatestAIReport", "fraudshieldReportDraft"];
  const ORDER = ["case", "evidence", "review", "report", "export"];

  function update(store) {
    const c = store[CASE_KEY] || {};
    const items = Array.isArray(c.items) ? c.items : [];
    const trail = Array.isArray(c.auditTrail) ? c.auditTrail : [];
    const review = store.fraudshieldLatestAIReport;
    const draft = store.fraudshieldReportDraft;
    const done = {
      case: !!(c.caseName && String(c.caseName).trim()),
      evidence: items.length > 0,
      review: !!(review && review.caseId && review.caseId === c.caseId),
      report: !!(draft && draft.caseId && draft.caseId === c.caseId),
      export: trail.some(e => e && e.action === "Case report exported")
    };
    const current = ORDER.find(s => !done[s]);
    document.querySelectorAll(".rail a").forEach(a => {
      const step = a.dataset.step;
      a.classList.toggle("done", !!done[step]);
      if (step === current) a.setAttribute("aria-current", "step"); else a.removeAttribute("aria-current");
      const label = a.querySelector("span").textContent;
      a.setAttribute("aria-label", `${label}: ${done[step] ? "done" : step === current ? "current step" : "not started"}`);
    });
    const count = document.getElementById("evidenceCount");
    if (count) count.textContent = `${items.length} ${items.length === 1 ? "item" : "items"}`;
  }

  function refresh() { chrome.storage.local.get(KEYS, update); }
  refresh();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && KEYS.some(k => k in changes)) refresh();
  });
})();
