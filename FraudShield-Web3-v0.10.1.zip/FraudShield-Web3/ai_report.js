function esc(s){return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");}
function inline(s){return esc(s).replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\*(.+?)\*/g,"<em>$1</em>").replace(/`([^`]+)`/g,"<code>$1</code>");}
function markdownToHtml(md){
 const lines=md.split(/\r?\n/);let html="",ul=false,ol=false;
 const closeLists=()=>{if(ul){html+="</ul>";ul=false;}if(ol){html+="</ol>";ol=false;}};
 for(let line of lines){const t=line.trim();if(!t){closeLists();continue;}
  const heading=t.match(/^#{1,4}\s+(.+)$/)||t.match(/^\*\*(.+)\*\*$/);
  if(heading){closeLists();html+=`<h4>${inline(heading[1])}</h4>`;continue;}
  if(/^[-*•]\s+/.test(t)){if(ol){html+="</ol>";ol=false;}if(!ul){html+="<ul>";ul=true;}html+=`<li>${inline(t.replace(/^[-*•]\s+/,""))}</li>`;continue;}
  if(/^\d+[.)]\s+/.test(t)){if(ul){html+="</ul>";ul=false;}if(!ol){html+="<ol>";ol=true;}html+=`<li>${inline(t.replace(/^\d+[.)]\s+/,""))}</li>`;continue;}
  if(/^>\s?/.test(t)){closeLists();html+=`<blockquote>${inline(t.replace(/^>\s?/,""))}</blockquote>`;continue;}
  closeLists();html+=`<p>${inline(t)}</p>`;
 }
 closeLists();return html;
}
const requestedReviewId=new URLSearchParams(location.search).get("reviewId");
const requestedKey=requestedReviewId?`fraudshieldAIReview_${requestedReviewId}`:"fraudshieldLatestAIReport";
chrome.storage.local.get([requestedKey,"fraudshieldLatestAIReport"],r=>{
 const report=r[requestedKey]||(requestedReviewId?null:r.fraudshieldLatestAIReport);
 if(!report){document.getElementById("reportBody").innerHTML="<p>This review could not be found. Run a new AI review from FraudShield. The requested review ID was not replaced with a different report.</p>";return;}
 document.getElementById("caseTitle").textContent=report.caseName||"Untitled case";
 const stamp=report.generatedAt?new Date(report.generatedAt).toLocaleString():"time unavailable";
 const evidenceMeta=report.evidenceCount!=null?` · ${report.evidenceCount} evidence item(s)`:"";
 const reviewMeta=report.reviewId?` · ${report.reviewId}`:"";
 document.getElementById("caseMeta").textContent=`${report.category||"Uncategorized"} · Reviewed ${stamp}${evidenceMeta}${reviewMeta}`;
 document.getElementById("modelBadge").textContent=report.model||"Local model";
 document.getElementById("reportBody").innerHTML=markdownToHtml(report.answer||"No review content.");
});
document.getElementById("closeBtn").addEventListener("click",()=>window.close());